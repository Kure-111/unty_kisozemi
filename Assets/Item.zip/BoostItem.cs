using System.Collections;
using System.Collections.Generic;
using UnityEngine;

private bool isSpeedBoosted = false;

void Start()
{
    StartCoroutine(ActivateSkill());
}

//ブースト開始
IEnumerator ActivateSkill()
{
    while (true)
    {
        yield return new WaitForSeconds(30f);

        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (!isSpeedBoosted)
            {
                StartCoroutine(BoostSpeed());
            }
        }
    }
}

IEnumerator BoostSpeed()
{
    float originalSpeed = carControl.speed;
    float targetSpeed = originalSpeed * 1.5f;
    float elapsedTime = 0f;

    isSpeedBoosted = true;

    while (elapsedTime < 6f)
    {
        elapsedTime += Time.deltaTime;
        carControl.speed = Mathf.Lerp(originalSpeed, targetSpeed, elapsedTime / 6f);
        yield return null;
    }

    carControl.speed = originalSpeed;
    isSpeedBoosted = false;
}
